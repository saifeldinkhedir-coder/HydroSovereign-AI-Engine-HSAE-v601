"""
geoagent_tool.py — HSAE v6.0.8  Tool #16: GeoAgent Tools
==========================================================
Run all 9 HSAE GeoAgent tools directly from inside QGIS.

Integrates with opengeos/GeoAgent (PR #79, merged May 2026).
Import-safe: works without geoagent installed — falls back to
calling HSAE indices directly.

Author : Seifeldin M.G. Alkhedir · University of Khartoum
ORCID  : 0000-0003-0821-2991
GitHub : github.com/opengeos/GeoAgent/pull/79
"""
from __future__ import annotations

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QComboBox,
    QPushButton, QTextEdit, QLabel, QProgressBar,
    QGroupBox, QRadioButton, QButtonGroup,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont, QColor

# Basin display names → HSAE IDs
BASIN_NAMES = [
    "Blue Nile / GERD",
    "Mekong / Lancang",
    "Euphrates / Atatürk",
    "Tigris / Mosul",
    "Indus / Tarbela",
    "Ganges / Farakka",
    "Danube / Gabčíkovo",
    "Rhine / Basin",
    "Nile / Aswan",
    "Zambezi / Kariba",
    "Niger / Kainji",
    "Congo / Inga",
    "Amazon / Itaipú",
    "Colorado / Hoover",
    "Columbia / Bonneville",
    "Salween / Nu Jiang",
    "Amu Darya / Nurek",
    "Syr Darya / Toktogul",
    "Orange / Vanderkloof",
    "Volta / Akosombo",
    "Ob-Irtysh / Basin",
    "Yenisei / Sayano",
    "Lena / Vilyui",
    "Murray / Hume",
    "La Plata / Yacyretá",
    "Senegal / Manantali",
]

TOOL_NAMES = [
    "analyze_basin_compliance  — Full run (all 6 indices)",
    "compute_atdi              — Transparency Deficit Index",
    "compute_afsf              — Forensic Signal Factor",
    "compute_ahifd             — Human-Induced Flow Deficit",
    "compute_atci              — Treaty Compliance Index",
    "compute_conflict_index    — Composite Conflict Index",
    "compute_adts              — Digital Transparency Score",
    "run_unwc_compliance       — Full UNWC screen",
    "get_negotiation_recommendation — AI pathway",
]

TOOL_KEYS = [
    "analyze_basin_compliance",
    "compute_atdi",
    "compute_afsf",
    "compute_ahifd",
    "compute_atci",
    "compute_conflict_index",
    "compute_adts",
    "run_unwc_compliance",
    "get_negotiation_recommendation",
]


class _RunThread(QThread):
    """Worker thread — keeps QGIS UI responsive during tool execution."""
    result_ready = pyqtSignal(str)
    error_signal  = pyqtSignal(str)

    def __init__(self, tool_key: str, basin_name: str):
        super().__init__()
        self.tool_key   = tool_key
        self.basin_name = basin_name

    def run(self):
        try:
            result = _call_tool(self.tool_key, self.basin_name)
            self.result_ready.emit(_format_result(result))
        except Exception as exc:
            self.error_signal.emit(f"Error: {exc}")


def _call_tool(tool_key: str, basin_name: str) -> dict:
    """Call HSAE tool — via geoagent if available, else direct fallback."""
    # Clean basin name for resolver
    clean = basin_name.split(" / ")[0].strip()

    try:
        from geoagent.tools.hsae import hsae_tools  # type: ignore[import-not-found]
        tools = {t.tool_name: t for t in hsae_tools()}
        return tools[tool_key](clean)
    except ImportError:
        # Fallback: call HSAE indices directly
        return _direct_fallback(tool_key, clean)


def _direct_fallback(tool_key: str, basin_name: str) -> dict:
    """Direct HSAE call when geoagent is not installed."""
    try:
        from hydrosovereign import get_index, analyze_basin  # type: ignore[import-not-found]
        if tool_key == "analyze_basin_compliance":
            return analyze_basin(basin_name.lower().replace(" ", "_"))
        idx = tool_key.replace("compute_", "").upper()
        val = get_index(basin_name.lower().replace(" ", "_"), idx)
        return {idx: val, "basin": basin_name, "source": "hydrosovereign direct"}
    except ImportError:
        pass

    # Pure-Python ERA5 fallback (always works, no credentials)
    try:
        from geoagent.tools.hsae import _resolve_basin_id, _compute_fallback_indices, _legal_status  # type: ignore[import-not-found]
        basin_id = _resolve_basin_id(basin_name)
        atdi, ahifd, atci, ci = _compute_fallback_indices(basin_id)
        adts = round(100.0 - atdi, 2)
        legal = _legal_status(atdi)
        return {
            "basin": basin_name,
            "ATDI_pct": atdi, "AHIFD_pct": ahifd,
            "ATCI_pct": atci, "CI_score": ci,
            "ADTS_pct": adts, "AFSF_pct": round(min(atdi * 1.35, 100), 2),
            "legal_status": legal["status"],
            "triggered_articles": legal["triggered_articles"],
            "source": "ERA5 fallback (install geoagent for full pipeline)",
        }
    except Exception as e:
        return {"error": str(e), "basin": basin_name}


def _format_result(result: dict) -> str:
    """Format tool result dict as readable text for the output pane."""
    lines = []
    for k, v in result.items():
        if k == "findings" and isinstance(v, list):
            lines.append("findings:")
            for f in v:
                art = f.get("article", "")
                st  = f.get("status", "")
                val = f.get("value", "")
                lines.append(f"  {art}  {st}  {val}")
        elif k == "indices" and isinstance(v, dict):
            lines.append("indices:")
            for ik, iv in v.items():
                lines.append(f"  {ik:<15} = {iv}")
        else:
            lines.append(f"{k:<25} = {v}")
    return "\n".join(lines)


class HSAEGeoAgentDialog(QDialog):
    """
    Tool #16 — GeoAgent Tools Dialog.

    Provides a QGIS-native UI to run all 9 HSAE GeoAgent tools
    without leaving the QGIS Desktop environment.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("HSAE Tool #16 — GeoAgent Tools  (opengeos ecosystem)")
        self.setMinimumSize(680, 560)
        self._thread = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(10)

        # ── Header ────────────────────────────────────────────────────────────
        hdr = QLabel(
            "<b style='font-size:13px;color:#1B3F6B;'>"
            "🤖  HSAE GeoAgent Tools</b><br>"
            "<span style='color:#555;font-size:10px;'>"
            "opengeos ecosystem · PR #79 merged by Prof. Qiusheng Wu · "
            "<a href='https://github.com/opengeos/GeoAgent/pull/79'>github.com/opengeos/GeoAgent</a>"
            "</span>"
        )
        hdr.setOpenExternalLinks(True)
        hdr.setTextFormat(Qt.RichText)
        root.addWidget(hdr)

        # ── Selectors ─────────────────────────────────────────────────────────
        sel_box = QGroupBox("Select basin and tool")
        sel_layout = QVBoxLayout(sel_box)

        basin_row = QHBoxLayout()
        basin_row.addWidget(QLabel("Basin:"))
        self.basin_combo = QComboBox()
        self.basin_combo.addItems(BASIN_NAMES)
        basin_row.addWidget(self.basin_combo, 1)
        sel_layout.addLayout(basin_row)

        tool_row = QHBoxLayout()
        tool_row.addWidget(QLabel("Tool:"))
        self.tool_combo = QComboBox()
        self.tool_combo.addItems(TOOL_NAMES)
        tool_row.addWidget(self.tool_combo, 1)
        sel_layout.addLayout(tool_row)

        root.addWidget(sel_box)

        # ── Run button + progress ─────────────────────────────────────────────
        btn_row = QHBoxLayout()
        self.run_btn = QPushButton("▶  Run Tool")
        self.run_btn.setStyleSheet(
            "QPushButton{background:#1B3F6B;color:white;font-weight:bold;"
            "padding:6px 20px;border-radius:4px;}"
            "QPushButton:hover{background:#2557A0;}"
            "QPushButton:disabled{background:#aaa;}"
        )
        self.run_btn.clicked.connect(self._run)
        btn_row.addWidget(self.run_btn)

        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(lambda: self.output.clear())
        btn_row.addWidget(self.clear_btn)
        btn_row.addStretch()

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        self.progress.setFixedHeight(10)
        root.addLayout(btn_row)
        root.addWidget(self.progress)

        # ── Output ────────────────────────────────────────────────────────────
        root.addWidget(QLabel("Output:"))
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setFont(QFont("Courier New", 9))
        self.output.setStyleSheet(
            "background:#0F1117;color:#e2e8f0;border-radius:4px;padding:8px;"
        )
        root.addWidget(self.output, 1)

        # ── Status bar ────────────────────────────────────────────────────────
        self.status_lbl = QLabel("Ready — select a basin and tool, then press Run.")
        self.status_lbl.setStyleSheet("color:#666;font-size:9px;")
        root.addWidget(self.status_lbl)

        # ── Install hint ──────────────────────────────────────────────────────
        hint = QLabel(
            "<span style='color:#888;font-size:9px;'>"
            "Full pipeline: <code>pip install geoagent hydrosovereign</code> — "
            "ERA5 fallback always active without installation."
            "</span>"
        )
        hint.setTextFormat(Qt.RichText)
        root.addWidget(hint)

    def _run(self):
        basin = self.basin_combo.currentText()
        tool_idx = self.tool_combo.currentIndex()
        tool_key = TOOL_KEYS[tool_idx]

        self.run_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.status_lbl.setText(f"Running {tool_key} for {basin.split('/')[0].strip()}…")

        self._thread = _RunThread(tool_key, basin)
        self._thread.result_ready.connect(self._on_result)
        self._thread.error_signal.connect(self._on_error)
        self._thread.finished.connect(self._on_done)
        self._thread.start()

    def _on_result(self, text: str):
        basin = self.basin_combo.currentText()
        tool_key = TOOL_KEYS[self.tool_combo.currentIndex()]
        header = (f"{'═'*60}\n"
                  f"Tool    : {tool_key}\n"
                  f"Basin   : {basin}\n"
                  f"{'═'*60}\n")
        self.output.append(header + text + "\n")

    def _on_error(self, msg: str):
        self.output.append(f"⚠️  {msg}\n")

    def _on_done(self):
        self.run_btn.setEnabled(True)
        self.progress.setVisible(False)
        self.status_lbl.setText("Done. Select another tool or basin to continue.")
